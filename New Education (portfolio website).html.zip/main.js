function showalert() {
  alert("All courses are below! Learn any course free of cost");
  return false;
}
